import express from "express";
import { isAdmin, isAuthenticate, isUser } from "../middlewares/auth.js";
import { multipleUpload } from "../middlewares/multer.js";
import { addToCart,getAllCarts,updateCartQuantity,removeFromCart} from "../controllers/cartController.js";
const router = express.Router();

router.get("/cart",isAuthenticate, isUser, getAllCarts);
router.post("/cart",isAuthenticate, isUser, addToCart)
router.put("/cart",isAuthenticate, isUser, updateCartQuantity);
router.delete("/cart",isAuthenticate, isUser, removeFromCart);

export default router;