const USERTYPE = {
    ADMIN : "Admin",
    USER : "User",
    RESTAURANT : "Restaurant"
}

const STATUS_CODE = {
    SUCCESS : 200,
    CREATED : 201,
    NOT_AVAILABLE : 204,
    BAD_REQUEST : 400,
    NOT_AUTHORIZED : 401,
    FORBIDDEN : 403,
    NOT_FOUND : 404,
    CONFLICT : 409,
    INTERNAL_SERVER_ERROR : 500
}

const staticMessages =  {
    NOT_FOUND : "Data not found!",
    INTERNAL_SERVER_ERROR : "Internal Server Error!",
    MISSING_REQUIRED_FIELDS : "Missing requied fields!",
    ROUTE_NOT_FOUND : "Route not exists!",
    PASSWORD_DID_NOT_MATCH : "Password didn't match",
    LOGIN_SUCCESS : "Login successfully!",
    LOGOUT_SUCCESS : "Logout successfully!",
    FOUND : "Data fetched successfully!",
    FORBIDDEN : "You are not allowed to perform this action",
    TOKEN_MISSING : "Token is missing!",
    TOKEN_EXPIRED : "Token is expired!",
    TOKEN_VERIFICATION_FAILED : "Token verification failed!",

    USER_CREATE : "User created successfully!",
    USER_UPDATE : "User updated successfully!",
    USER_ALREADY_EXISTS : "User already exists with this email!",
    USER_DELETE : "User deleted successfully!",

    RESTAURANT_CREATE : "Restaurant created successfully!",
    RESTAURANT_UPDATE : "Restaurant updated successfully!",

    PRODUCT_CREATED :  "Product created successfully!",
    PRODUCT_UPDATED :  "Product updated successfully!",
    PRODUCT_DELETED : "Product delete successfully!"
}

export {STATUS_CODE,staticMessages,USERTYPE}